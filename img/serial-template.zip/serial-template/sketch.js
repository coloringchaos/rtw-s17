// P5 STUFF ONLY

function setup() {

}

function draw() {

}


////////////////////////////////////////////////

// all non-p5 javascript needs to go inside init() 
// so that this code executes only AFTER the page has loaded

function init(){

	// SOCKET STUFF
	var socket = io.connect();

	socket.on('connect', function() {
		console.log("Connected");
	});

}

window.addEventListener('load', init);


