// P5 STUFF

function setup() {

}

function draw() {

}


//// OTHER JS STUFF CAN GO HERE
// function init(){


// }

// window.addEventListener('load', init);


